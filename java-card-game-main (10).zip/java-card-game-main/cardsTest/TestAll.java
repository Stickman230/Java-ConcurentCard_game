//import all the required component for testing 
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

// initialise test suite
@RunWith(Suite.class)
@Suite.SuiteClasses({CardTest.class, DeckTest.class, PackTest.class, /*PlayerTest.class*/})

public class TestAll{

}