# java-card-game
Software Dev Coursework
multi-threaded card playing simulation

-The game has n players, each numbered 1 to n
-Each player will hold a hand of 4 cards
-n being a positive integer
-n decks of cards, again, each numbered 1 to “n"
-these hands and the decks will be drawn from a pack which contains “8n” cards.
- Each card has a face value of a nonnegative integer
-At the start of the game, each player will be distributed four cards in a round-robin fashion
-one card to player1, then one card to player2,
etc

to run the tests : java -cp .\lib\junit-4.13.2.jar`;`.\lib\hamcrest-core-1.3.jar.`;`.`; TestRunner.java

(DO NOT COPY FROM PREVIEW, COPY FROM SOURCE CODE)
