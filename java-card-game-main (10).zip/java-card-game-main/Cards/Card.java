public class Card {
    String faceValue;

    // Card constructor
    public Card(String val) {
        this.faceValue = val;
    }

    // Define get method used for card preference and comparison
    public String getFaceValue() {
        return faceValue;
    }
}
